package com.example.primerospasos

fun main(){

    println("Hola mundo")

}