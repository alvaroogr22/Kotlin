package com.example.bucles

fun main() {

    println("Tabla de multiplicar del 5 usando bucle do-while:")
    var i = 1
    do {
        val resultado = 5 * i
        println("5 * $i = $resultado")
        i++
    } while (i <= 10)


}




